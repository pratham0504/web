const { MongoClient } = require("mongodb");
const uri = "mongodb://localhost:27017";

const client = new MongoClient(uri);

const dbname ="ishita";

async function main(){
    
    await client.connect();
    console.log("Connection successful");
    const db = client.db(dbname);
    const collection = db.collection("users");

    //Insert 
    const I= await collection.insertMany([{name:"ishita", age:21},{name:"gautam", age:20}]);
    console.log("Docs inserted: ",I.insertedCount);

    //Read
    const R= await collection.find({}, {projection:{_id:0, name: 1, age:1}}).toArray();
    console.log("Users", R);

    //Update

    const U = await collection.updateOne({name:"gautam"},{$set:{age:21}});
    console.log("Docs updated: ",U.updatedCount);

    //Delete

    const D = await collection.deleteOne({name:"ishita"});
    console.log("Docs deleted: ",D.modifiedCount);


    //Read again
   
    const UR= await collection.find({}, {projection:{_id:0, name: 1, age:1}}).toArray();
    console.log("Users", UR);

}
    

   


main();


