const { MongoClient } = require("mongodb");
const uri = "mongodb://localhost:27017";

const client = new MongoClient(uri);
const dbName = "sakec";

async function main(){
    try{
        //Connection to mongodb
        await client.connect();
        console.log("Connected Successfully to MongoDb");

        //accessing the database and collection
        const db = client.db(dbName);
        const collection = db.collection("users");
        
        //Insert in database

        const insertManyResult = await collection.insertMany(
            [
                { name: "Alice", age: 25 },
                { name: "Bob", age: 28 },
                { name: "Charlie", age: 35 }
            ]
        )

        console.log("Inserted documents:", insertManyResult.insertedCount);

        //Read operation: Show all users
        const users = await collection.find({}, {projection: {_id:0, name: 1, age: 1}}).toArray();
        console.log("Users Collection Data: ", users);

        //Update

        const updateResult = await collection.updateOne(
            {name: "Alice"},
            {$set: { age:26}}
        );
        console.log("Modified documents:" , updateResult.modifiedCount);

        //Delete Operation
        const deleteResult = await collection.deleteOne({name : "Bob"});
        console.log("Deleted documents:", deleteResult.deletedCount);

        //Show Updated Users

        const updatedUsers = await collection.find({},{projection: {_id: 0, name: 1, age:1 }}).toArray();
        console.log("Updated users:" , updatedUsers);

    

    }
    catch(err){
        console.error("error:" , err);


    }finally{

        await client.close();
    }

}

main();