var dis = document.getElementById("display");
function append(value) {
    dis.value += value;
}
function clearDisplay() {
    dis.value = ' ';
}
function calculate() {
    try {
        dis.value = eval(dis.value).toString();
    }
    catch (_a) {
        dis.value = "Error";
    }
}
