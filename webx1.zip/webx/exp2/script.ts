let currentInput: string = '';

// Get the display element (input) by its ID
const display = document.getElementById('display') as HTMLInputElement;

function updateDisplay() {
    display.value = currentInput;
}

function appendToDisplay(value: string) {
    currentInput += value;
    updateDisplay();
}

function clearDisplay() {
    currentInput = '';
    updateDisplay();
}

function calculateResult() {
    try {
        // Use eval to evaluate the current input expression
        currentInput = eval(currentInput).toString();
        updateDisplay();
    } catch {
        currentInput = 'Error';
        updateDisplay();
    }
}
