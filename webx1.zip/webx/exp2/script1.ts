const dis= document.getElementById("display") as HTMLInputElement

function append(value : string): void{
    dis.value += value;

}

function clearDisplay(): void{
    dis.value = ' ' ;
}

function calculate(){
    try{
        dis.value=eval(dis.value).toString();
    }
    catch{
        dis.value = "Error";
    }
}