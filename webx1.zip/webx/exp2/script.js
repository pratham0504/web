var currentInput = '';
// Get the display element (input) by its ID
var display = document.getElementById('display');
function updateDisplay() {
    display.value = currentInput;
}
function appendToDisplay(value) {
    currentInput += value;
    updateDisplay();
}
function clearDisplay() {
    currentInput = '';
    updateDisplay();
}
function calculateResult() {
    try {
        // Use eval to evaluate the current input expression
        currentInput = eval(currentInput).toString();
        updateDisplay();
    }
    catch (_a) {
        currentInput = 'Error';
        updateDisplay();
    }
}
