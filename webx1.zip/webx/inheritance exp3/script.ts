// Base class
class Shape {
    name: string;

    constructor(name: string) {
        this.name = name;
    }

    display(): string {
        return "Shape: " + this.name;
    }
    
}

// Derived class: Circle
class Circle extends Shape {
    radius: number;

    constructor(radius: number) {
        super("Circle");
        this.radius = radius;
    }

    area(): number {
        return Math.PI * this.radius * this.radius;
    }

    display(): string {
        return super.display() + "<br>Area: " + this.area().toFixed(2);
    }
    
}

// Derived class: Sphere
class Sphere extends Circle {
    constructor(radius: number) {
        super(radius);
        this.name = "Sphere"; // override name
    }

    volume(): number {
        return (4 / 3) * Math.PI * Math.pow(this.radius, 3);
    }

    display(): string {
        return super.display() + "<br>Volume: " + this.volume().toFixed(2);
    }
    
}

// Functions for button clicks
function createCircle(): void {
    const radiusInput = document.getElementById('radius') as HTMLInputElement;
    const outputDiv = document.getElementById('output') as HTMLDivElement;

    const radius = parseFloat(radiusInput.value);
    if (isNaN(radius) || radius <= 0) {
        alert('Please enter a valid radius!');
        return;
    }

    const circle = new Circle(radius);
    outputDiv.innerHTML = circle.display();
}

function createSphere(): void {
    const radiusInput = document.getElementById('radius') as HTMLInputElement;
    const outputDiv = document.getElementById('output') as HTMLDivElement;

    const radius = parseFloat(radiusInput.value);
    if (isNaN(radius) || radius <= 0) {
        alert('Please enter a valid radius!');
        return;
    }

    const sphere = new Sphere(radius);
    outputDiv.innerHTML = sphere.display();
}
