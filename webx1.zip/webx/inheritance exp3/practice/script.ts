class Shape{
    name: string;
    constructor(name: string){
        this.name = name;
    }
    display(): string{
        return "Shape:" +this.name;
    }
}
class Circle extends Shape{
    radius: number;
    constructor(radius: number){
        super("Circle")
        this.radius = radius;
    }
    Area(): number
    {
        return Math.PI * this.radius * this.radius;
    }
    display(): string{
        return super.display() + "<br>Area: " + this.Area()
    }
}
class Sphere extends Circle{
    constructor(radius : number){
        super(radius);
        this.name = "Sphere";
    }
    volume(): number
    {
        return Math.PI * this.radius * this.radius * this.radius;
    }
    display():string{
        return super.display() + "<br>Volume: " + this.volume()
    }
}
function createCircle():void{
    const radiusInput = document.getElementById("radius") as HTMLInputElement;
    const outputdiv = document.getElementById("output") as HTMLDivElement;

    const radius = parseFloat(radiusInput.value);
    if(isNaN(radius) || radius <= 0)
    {
        alert("pls enter valid radius");
    }
    else{
        const circle = new Circle(radius);
        outputdiv.innerHTML=circle.display();
    }

}

function createSphere():void{
    const radiusInput = document.getElementById("radius") as HTMLInputElement;
    const outputdiv = document.getElementById("output") as HTMLDivElement;

    const radius = parseFloat(radiusInput.value);
    if(isNaN(radius) || radius <= 0)
    {
        alert("pls enter valid radius");
    }
    else{
        const sphere = new Sphere(radius);
        outputdiv.innerHTML = sphere.display();
    }

}