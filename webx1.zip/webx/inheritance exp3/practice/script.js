var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Shape = /** @class */ (function () {
    function Shape(name) {
        this.name = name;
    }
    Shape.prototype.display = function () {
        return "Shape:" + this.name;
    };
    return Shape;
}());
var Circle = /** @class */ (function (_super) {
    __extends(Circle, _super);
    function Circle(radius) {
        var _this = _super.call(this, "Circle") || this;
        _this.radius = radius;
        return _this;
    }
    Circle.prototype.Area = function () {
        return Math.PI * this.radius * this.radius;
    };
    Circle.prototype.display = function () {
        return _super.prototype.display.call(this) + "<br>Area: " + this.Area();
    };
    return Circle;
}(Shape));
var Sphere = /** @class */ (function (_super) {
    __extends(Sphere, _super);
    function Sphere(radius) {
        var _this = _super.call(this, radius) || this;
        _this.name = "Sphere";
        return _this;
    }
    Sphere.prototype.volume = function () {
        return Math.PI * this.radius * this.radius * this.radius;
    };
    Sphere.prototype.display = function () {
        return _super.prototype.display.call(this) + "<br>Volume: " + this.volume();
    };
    return Sphere;
}(Circle));
function createCircle() {
    var radiusInput = document.getElementById("radius");
    var outputdiv = document.getElementById("output");
    var radius = parseFloat(radiusInput.value);
    if (isNaN(radius) || radius <= 0) {
        alert("pls enter valid radius");
    }
    else {
        var circle = new Circle(radius);
        outputdiv.innerHTML = circle.display();
    }
}
function createSphere() {
    var radiusInput = document.getElementById("radius");
    var outputdiv = document.getElementById("output");
    var radius = parseFloat(radiusInput.value);
    if (isNaN(radius) || radius <= 0) {
        alert("pls enter valid radius");
    }
    else {
        var sphere = new Sphere(radius);
        outputdiv.innerHTML = sphere.display();
    }
}
