var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
// Base class
var Shape = /** @class */ (function () {
    function Shape(name) {
        this.name = name;
    }
    Shape.prototype.display = function () {
        return "Shape: ".concat(this.name);
    };
    return Shape;
}());
// Derived class: Circle
var Circle = /** @class */ (function (_super) {
    __extends(Circle, _super);
    function Circle(radius) {
        var _this = _super.call(this, "Circle") || this;
        _this.radius = radius;
        return _this;
    }
    Circle.prototype.area = function () {
        return Math.PI * this.radius * this.radius;
    };
    Circle.prototype.display = function () {
        return "".concat(_super.prototype.display.call(this), "<br>Area: ").concat(this.area().toFixed(2));
    };
    return Circle;
}(Shape));
// Derived class: Sphere
var Sphere = /** @class */ (function (_super) {
    __extends(Sphere, _super);
    function Sphere(radius) {
        var _this = _super.call(this, radius) || this;
        _this.name = "Sphere"; // override name
        return _this;
    }
    Sphere.prototype.volume = function () {
        return (4 / 3) * Math.PI * Math.pow(this.radius, 3);
    };
    Sphere.prototype.display = function () {
        return "".concat(_super.prototype.display.call(this), "<br>Volume: ").concat(this.volume().toFixed(2));
    };
    return Sphere;
}(Circle));
// Functions for button clicks
function createCircle() {
    var radiusInput = document.getElementById('radius');
    var outputDiv = document.getElementById('output');
    var radius = parseFloat(radiusInput.value);
    if (isNaN(radius) || radius <= 0) {
        alert('Please enter a valid radius!');
        return;
    }
    var circle = new Circle(radius);
    outputDiv.innerHTML = circle.display();
}
function createSphere() {
    var radiusInput = document.getElementById('radius');
    var outputDiv = document.getElementById('output');
    var radius = parseFloat(radiusInput.value);
    if (isNaN(radius) || radius <= 0) {
        alert('Please enter a valid radius!');
        return;
    }
    var sphere = new Sphere(radius);
    outputDiv.innerHTML = sphere.display();
}
