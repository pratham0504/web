class Shape {
    name: string;

    constructor(name: string) {
        this.name = name;
    }

    display(): string {
        return `Shape: ${this.name}`;
    }
}

class Rectangle extends Shape {
    length: number;
    breadth: number;

    constructor(length: number, breadth: number) {
        super("Rectangle");
        this.length = length;
        this.breadth = breadth;
    }

    area(): number {
        return this.length * this.breadth;
    }

    display(): string {
        return `${super.display()}<br>Area: ${this.area().toFixed(2)}`;
    }
}

class Cuboid extends Rectangle {
    height: number;

    constructor(length: number, breadth: number, height: number) {
        super(length, breadth);
        this.height = height;
        this.name = "Cuboid";
    }

    volume(): number {
        return this.length * this.breadth * this.height;
    }

    display(): string {
        return `${super.display()}<br>Volume: ${this.volume().toFixed(2)}`;
    }
}

// GUI interaction
function calculate(): void {
    const length = parseFloat((document.getElementById("length") as HTMLInputElement).value);
    const breadth = parseFloat((document.getElementById("breadth") as HTMLInputElement).value);
    const height = parseFloat((document.getElementById("height") as HTMLInputElement).value);
    const shape = (document.getElementById("shape") as HTMLSelectElement).value;
    const output = document.getElementById("output") as HTMLDivElement;

    if (isNaN(length) || isNaN(breadth) || length <= 0 || breadth <= 0) {
        output.innerHTML = "Please enter valid length and breadth.";
        return;
    }

    if (shape === "rectangle") {
        const rect = new Rectangle(length, breadth);
        output.innerHTML = rect.display();
    } else {
        if (isNaN(height) || height <= 0) {
            output.innerHTML = "Please enter valid height for cuboid.";
            return;
        }
        const cuboid = new Cuboid(length, breadth, height);
        output.innerHTML = cuboid.display();
    }
}
