var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Shape = /** @class */ (function () {
    function Shape(name) {
        this.name = name;
    }
    Shape.prototype.display = function () {
        return "Shape: ".concat(this.name);
    };
    return Shape;
}());
var Rectangle = /** @class */ (function (_super) {
    __extends(Rectangle, _super);
    function Rectangle(length, breadth) {
        var _this = _super.call(this, "Rectangle") || this;
        _this.length = length;
        _this.breadth = breadth;
        return _this;
    }
    Rectangle.prototype.area = function () {
        return this.length * this.breadth;
    };
    Rectangle.prototype.display = function () {
        return "".concat(_super.prototype.display.call(this), "<br>Area: ").concat(this.area().toFixed(2));
    };
    return Rectangle;
}(Shape));
var Cuboid = /** @class */ (function (_super) {
    __extends(Cuboid, _super);
    function Cuboid(length, breadth, height) {
        var _this = _super.call(this, length, breadth) || this;
        _this.height = height;
        _this.name = "Cuboid";
        return _this;
    }
    Cuboid.prototype.volume = function () {
        return this.length * this.breadth * this.height;
    };
    Cuboid.prototype.display = function () {
        return "".concat(_super.prototype.display.call(this), "<br>Volume: ").concat(this.volume().toFixed(2));
    };
    return Cuboid;
}(Rectangle));
// GUI interaction
function calculate() {
    var length = parseFloat(document.getElementById("length").value);
    var breadth = parseFloat(document.getElementById("breadth").value);
    var height = parseFloat(document.getElementById("height").value);
    var shape = document.getElementById("shape").value;
    var output = document.getElementById("output");
    if (isNaN(length) || isNaN(breadth) || length <= 0 || breadth <= 0) {
        output.innerHTML = "Please enter valid length and breadth.";
        return;
    }
    if (shape === "rectangle") {
        var rect = new Rectangle(length, breadth);
        output.innerHTML = rect.display();
    }
    else {
        if (isNaN(height) || height <= 0) {
            output.innerHTML = "Please enter valid height for cuboid.";
            return;
        }
        var cuboid = new Cuboid(length, breadth, height);
        output.innerHTML = cuboid.display();
    }
}
