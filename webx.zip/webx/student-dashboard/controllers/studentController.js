app.controller("studentController", function($scope) {
  $scope.students = [
    { name: "John Doe", grade: 85 },
    { name: "Jane Smith", grade: 92 },
    { name: "Sam Brown", grade: 73 },
    { name: "Lisa White", grade: 65 }
  ];

  $scope.gradeFilter = "";

  $scope.addStudent = function() {
    if ($scope.newName && $scope.newGrade) {
      $scope.students.push({ name: $scope.newName, grade: parseInt($scope.newGrade) });
      $scope.newName = "";
      $scope.newGrade = "";
    }
  };

  $scope.removeStudent = function(index) {
    $scope.students.splice(index, 1);
  };

  $scope.customFilter = function(student) {
    return !$scope.gradeFilter || student.grade >= $scope.gradeFilter;
  };
});
