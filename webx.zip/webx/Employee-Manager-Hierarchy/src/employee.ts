export class Employee {
    public name: string;
    public age: number;
    public position: string;

    constructor(name: string, age: number, position: string) {
        this.name = name;
        this.age = age;
        this.position = position;
    }

    displayDetails(): string {
        return `${this.name}, Age: ${this.age}, Position: ${this.position}`;
    }
}