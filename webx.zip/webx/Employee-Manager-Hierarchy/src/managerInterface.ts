import { IEmployee } from './employeeInterface';

export interface IManager extends IEmployee {
    department: string;
}