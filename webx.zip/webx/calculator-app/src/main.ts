import { Calculator } from "./calculator.js";

document.addEventListener("DOMContentLoaded", () => {
  const calculator = new Calculator();
  const display = document.getElementById("display") as HTMLInputElement;
  const buttons = document.querySelectorAll("button");

  buttons.forEach((button) => {
    button.addEventListener("click", () => {
      const value = (button as HTMLButtonElement).dataset.value!;
      calculator.append(value);
      display.value = calculator.getInput();
    });
  });
});