export class Calculator {
    private currentInput = "";
  
    append(value: string): void {
      if (value === "C") {
        this.currentInput = "";
      } else if (value === "=") {
        this.currentInput = this.evaluate();
      } else if (value === "sqrt") {
        this.currentInput = this.handleSqrt();
      } else if (value === "^") {
        this.currentInput += "**";
      } else if (value === "%") {
        this.currentInput += "/100";
      } else {
        this.currentInput += value;
      }
    }
  
    getInput(): string {
      return this.currentInput;
    }
  
    private evaluate(): string {
      try {
        const result = eval(this.currentInput);
        return result.toString();
      } catch {
        return "Error";
      }
    }
  
    private handleSqrt(): string {
      try {
        const num = eval(this.currentInput);
        if (num < 0) throw new Error("Negative");
        return Math.sqrt(num).toString();
      } catch {
        return "Error";
      }
    }
  }