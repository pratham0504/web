"use strict";
var PasswordStrength;
(function (PasswordStrength) {
    PasswordStrength[PasswordStrength["None"] = 0] = "None";
    PasswordStrength[PasswordStrength["Weak"] = 1] = "Weak";
    PasswordStrength[PasswordStrength["Medium"] = 2] = "Medium";
    PasswordStrength[PasswordStrength["Strong"] = 3] = "Strong";
})(PasswordStrength || (PasswordStrength = {}));
// DOM Elements
const form = document.getElementById('registrationForm');
const nameInput = document.getElementById('name');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const confirmPasswordInput = document.getElementById('confirmPassword');
const phoneInput = document.getElementById('phone');
const submitButton = document.getElementById('submitButton');
const passwordStrengthBar = document.getElementById('passwordStrengthBar');
const submissionMessage = document.getElementById('submissionMessage');
// Error Elements
const nameError = document.getElementById('nameError');
const emailError = document.getElementById('emailError');
const passwordError = document.getElementById('passwordError');
const confirmPasswordError = document.getElementById('confirmPasswordError');
const phoneError = document.getElementById('phoneError');
// Initial form data
const formData = {
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: ''
};
// Initial validation errors
const errors = {
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: ''
};
// Add event listeners to form fields
nameInput.addEventListener('input', () => validateName());
emailInput.addEventListener('input', () => validateEmail());
passwordInput.addEventListener('input', () => {
    validatePassword();
    if (confirmPasswordInput.value) {
        validateConfirmPassword();
    }
});
confirmPasswordInput.addEventListener('input', () => validateConfirmPassword());
phoneInput.addEventListener('input', () => validatePhone());
// Form submission
form.addEventListener('submit', (e) => {
    e.preventDefault();
    // Final validation check before submission
    validateName();
    validateEmail();
    validatePassword();
    validateConfirmPassword();
    validatePhone();
    if (isFormValid()) {
        // In a real app, you would send the data to a server here
        console.log('Form submitted with data:', formData);
        // Show success message
        submissionMessage.style.display = 'block';
        // Reset form
        setTimeout(() => {
            form.reset();
            resetValidation();
            submissionMessage.style.display = 'none';
        }, 3000);
    }
});
// Validation functions
function validateName() {
    const value = nameInput.value.trim();
    formData.name = value;
    if (!value) {
        errors.name = 'Name is required';
        setError(nameInput, nameError, errors.name);
        return false;
    }
    if (value.length < 2) {
        errors.name = 'Name must be at least 2 characters';
        setError(nameInput, nameError, errors.name);
        return false;
    }
    errors.name = '';
    setSuccess(nameInput, nameError);
    return true;
}
function validateEmail() {
    const value = emailInput.value.trim();
    formData.email = value;
    if (!value) {
        errors.email = 'Email is required';
        setError(emailInput, emailError, errors.email);
        return false;
    }
    // RFC 5322 compliant email regex
    const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
    if (!emailRegex.test(value)) {
        errors.email = 'Please enter a valid email address';
        setError(emailInput, emailError, errors.email);
        return false;
    }
    errors.email = '';
    setSuccess(emailInput, emailError);
    return true;
}
function validatePassword() {
    const value = passwordInput.value;
    formData.password = value;
    if (!value) {
        errors.password = 'Password is required';
        setError(passwordInput, passwordError, errors.password);
        updatePasswordStrength(PasswordStrength.None);
        return false;
    }
    if (value.length < 8) {
        errors.password = 'Password must be at least 8 characters';
        setError(passwordInput, passwordError, errors.password);
        updatePasswordStrength(PasswordStrength.Weak);
        return false;
    }
    // Check password strength
    const strength = checkPasswordStrength(value);
    updatePasswordStrength(strength);
    if (strength === PasswordStrength.Weak) {
        errors.password = 'Password is too weak';
        setError(passwordInput, passwordError, errors.password);
        return false;
    }
    errors.password = '';
    setSuccess(passwordInput, passwordError);
    return true;
}
function validateConfirmPassword() {
    const value = confirmPasswordInput.value;
    formData.confirmPassword = value;
    if (!value) {
        errors.confirmPassword = 'Please confirm your password';
        setError(confirmPasswordInput, confirmPasswordError, errors.confirmPassword);
        return false;
    }
    if (value !== formData.password) {
        errors.confirmPassword = 'Passwords do not match';
        setError(confirmPasswordInput, confirmPasswordError, errors.confirmPassword);
        return false;
    }
    errors.confirmPassword = '';
    setSuccess(confirmPasswordInput, confirmPasswordError);
    return true;
}
function validatePhone() {
    const value = phoneInput.value.trim();
    formData.phone = value;
    if (!value) {
        errors.phone = 'Phone number is required';
        setError(phoneInput, phoneError, errors.phone);
        return false;
    }
    // Simple phone validation - allows formats like (123) 456-7890, 123-456-7890, 1234567890
    const phoneRegex = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/;
    if (!phoneRegex.test(value)) {
        errors.phone = 'Please enter a valid phone number';
        setError(phoneInput, phoneError, errors.phone);
        return false;
    }
    errors.phone = '';
    setSuccess(phoneInput, phoneError);
    return true;
}
// Utility functions
function setError(input, errorElement, message) {
    input.classList.remove('success');
    input.classList.add('error-input');
    errorElement.textContent = message;
    checkFormValidity();
}
function setSuccess(input, errorElement) {
    input.classList.remove('error-input');
    input.classList.add('success');
    errorElement.textContent = '';
    checkFormValidity();
}
function checkPasswordStrength(password) {
    // Check for various character types
    const hasLower = /[a-z]/.test(password);
    const hasUpper = /[A-Z]/.test(password);
    const hasNumber = /[0-9]/.test(password);
    const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    // Count the number of different character types
    const varietyCount = [hasLower, hasUpper, hasNumber, hasSpecial].filter(Boolean).length;
    // Evaluate strength based on length and variety
    if (password.length < 8) {
        return PasswordStrength.Weak;
    }
    else if (password.length >= 12 && varietyCount >= 3) {
        return PasswordStrength.Strong;
    }
    else if (password.length >= 8 && varietyCount >= 2) {
        return PasswordStrength.Medium;
    }
    else {
        return PasswordStrength.Weak;
    }
}
function updatePasswordStrength(strength) {
    // Remove all classes
    passwordStrengthBar.className = '';
    // Add appropriate class based on strength
    switch (strength) {
        case PasswordStrength.Weak:
            passwordStrengthBar.classList.add('weak');
            break;
        case PasswordStrength.Medium:
            passwordStrengthBar.classList.add('medium');
            break;
        case PasswordStrength.Strong:
            passwordStrengthBar.classList.add('strong');
            break;
        default:
            passwordStrengthBar.style.width = '0';
            return;
    }
}
function isFormValid() {
    return (errors.name === '' &&
        errors.email === '' &&
        errors.password === '' &&
        errors.confirmPassword === '' &&
        errors.phone === '' &&
        formData.name !== '' &&
        formData.email !== '' &&
        formData.password !== '' &&
        formData.confirmPassword !== '' &&
        formData.phone !== '');
}
function checkFormValidity() {
    submitButton.disabled = !isFormValid();
}
function resetValidation() {
    // Reset form data
    const keys = Object.keys(formData);
    keys.forEach(key => {
        formData[key] = '';
    });
    // Reset errors
    const errorKeys = Object.keys(errors);
    errorKeys.forEach(key => {
        errors[key] = '';
    });
    // Reset UI
    [nameInput, emailInput, passwordInput, confirmPasswordInput, phoneInput].forEach(input => {
        input.classList.remove('success', 'error-input');
    });
    [nameError, emailError, passwordError, confirmPasswordError, phoneError].forEach(error => {
        error.textContent = '';
    });
    // Reset password strength
    passwordStrengthBar.className = '';
    passwordStrengthBar.style.width = '0';
    // Disable submit button
    submitButton.disabled = true;
}
// Initialize form validation
resetValidation();
//# sourceMappingURL=form.js.map